<?php

namespace App\Models\Customer;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class CustomerPacel extends Model
{
    use HasFactory;

 

    protected $guarded = ['id'];


    public function customerPacel(){

        return $this->belogsTo('App\Models\Customer\Customer','pacel_id');
    }
}
