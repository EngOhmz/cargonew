<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PacelHistory extends Model
{
    use HasFactory;

    protected $guarded = ['id'];


    public function customerPacel(){

        return $this->belogsTo('App\Models\Customer\Customer','pacel_id');
    }
}
